#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强发布脚本 — 在 update_data_v2.py 之后、deploy 之前运行。
功能：
  1. 同步增强 getScore() JS 函数（master → dist）
  2. 同步 MAHORO_COVERAGE 数据
  3. 同步逻辑详解页 HTML（强烈关注推荐描述 + 增强评分因子表格）
"""
import json, re, os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
MASTER = os.path.join(BASE, "index_master.html")  # 根目录 master，与 update_data_v2.py 同源
DIST = os.path.join(BASE, "dist", "index.html")
DIST_MASTER = os.path.join(BASE, "dist", "index_master.html")  # 双文件同步
MAHORO = os.path.join(BASE, "data", "mahoro_signals.json")
LOG_FILE = os.path.join(BASE, "data", ".enhance_log.txt")

def sync_html_blocks(master, dist):
    """从 master 同步逻辑详解页的关键 HTML 块到 dist。"""
    changed = False

    # --- Block 1: 强烈关注推荐 ---
    m_rec = re.search(
        r'<b>🌟 强烈关注推荐</b>：.*?</div>',
        master, re.DOTALL
    )
    if m_rec:
        new_rec = m_rec.group(0)
        old_rec = re.search(
            r'<b>🌟 强烈关注推荐</b>：.*?</div>',
            dist, re.DOTALL
        )
        if old_rec and old_rec.group(0) != new_rec:
            dist = dist[:old_rec.start()] + new_rec + dist[old_rec.end():]
            changed = True
            print("✓ 强烈关注推荐 描述已同步")
        elif not old_rec:
            print("⚠ 强烈关注推荐 未在 dist 中找到，跳过")
    else:
        print("⚠ 强烈关注推荐 未在 master 中找到")

    # --- Block 2: 增强评分因子表格 ---
    m_enhance = re.search(
        r'<!-- 增强评分因子.*?<!-- 扫描与风险提示 -->',
        master, re.DOTALL
    )
    if m_enhance:
        enhance_block = m_enhance.group(0)
        dist_has_enhance = '<!-- 增强评分因子' in dist
        if dist_has_enhance:
            old_enhance = None
            for end_marker in ['<!-- 金股观测排序 -->', '<!-- 扫描与风险提示 -->']:
                old_enhance = re.search(
                    r'<!-- 增强评分因子.*?' + re.escape(end_marker),
                    dist, re.DOTALL
                )
                if old_enhance:
                    break
            if old_enhance and old_enhance.group(0) != enhance_block:
                dist = dist[:old_enhance.start()] + enhance_block + dist[old_enhance.end():]
                changed = True
                print("✓ 增强评分因子 表格已更新")
            else:
                print("✓ 增强评分因子 表格无需更新")
        else:
            insert_pos = -1
            for marker in ['<!-- 金股观测排序 -->', '<!-- 扫描与风险提示 -->']:
                insert_pos = dist.find(marker)
                if insert_pos >= 0:
                    break
            if insert_pos >= 0:
                dist = dist[:insert_pos] + enhance_block + '\n      ' + dist[insert_pos:]
                changed = True
                print("✓ 增强评分因子 表格已注入")
            else:
                print("⚠ 未找到注入锚点，增强评分因子 注入失败")
    else:
        print("⚠ 增强评分因子 未在 master 中找到")

    return dist, changed


def enhance_dist_file(dist_path):
    """对单个 dist 文件执行增强注入，返回是否成功"""
    if not os.path.exists(dist_path):
        print(f"  ⚠ {os.path.basename(dist_path)} 不存在，跳过")
        return False

    # 1. 读取 master
    with open(MASTER, "r", encoding="utf-8") as f:
        master = f.read()

    # 2. 提取增强 getScore
    m = re.search(r'function getScore\(c\).*?return score;\s*\}', master, re.DOTALL)
    if not m:
        print("❌ getScore not found in master, skipping enhance")
        return False
    new_getScore = m.group(0)

    # 3. 读取 dist 文件
    with open(dist_path, "r", encoding="utf-8") as f:
        dist = f.read()

    # 4. 替换旧 getScore
    dist = re.sub(
        r'function getScore\(c\).*?return score;\s*\}',
        new_getScore, dist, count=1, flags=re.DOTALL
    )
    print(f"  ✓ Enhanced getScore injected ({len(new_getScore)} chars)")

    # 5. 注入 MAHORO_COVERAGE + MAHORO_DETAIL（如果存在）
    if os.path.exists(MAHORO):
        with open(MAHORO, "r", encoding="utf-8") as f:
            mdata = json.load(f)
        coverage = {}
        detail = {}
        for match in mdata.get("gold_pool_matches", []):
            c = match.get("code", "")
            s = match.get("stance", "")
            if c and s:
                coverage[c] = s
                detail[c] = {
                    "bank": match.get("bank", ""),
                    "stance": s,
                    "key_point": match.get("key_point", "")
                }
        cov_json = json.dumps(coverage, ensure_ascii=False)
        det_json = json.dumps(detail, ensure_ascii=False)

        # 移除旧 MAHORO_COVERAGE / MAHORO_DETAIL
        dist = re.sub(
            r'const MAHORO_COVERAGE = \{.*?\};\s*',
            '', dist, count=1, flags=re.DOTALL
        )
        dist = re.sub(
            r'const MAHORO_DETAIL = \{.*?\};\s*',
            '', dist, count=1, flags=re.DOTALL
        )

        # 插入到 LHB_DATA 之前
        mahoro_block = f'const MAHORO_COVERAGE = {cov_json};\nconst MAHORO_DETAIL = {det_json};'
        insert_pos = dist.find('const LHB_DATA = {')
        if insert_pos < 0:
            insert_pos = dist.find('const MAIN_STOCK_DATA = {')
        if insert_pos >= 0:
            dist = dist[:insert_pos] + mahoro_block + '\n' + dist[insert_pos:]
            print(f"  ✓ 投行覆盖: {len(coverage)} stocks (+detail)")

    # 6. 同步逻辑详解页 HTML 块
    dist, html_changed = sync_html_blocks(master, dist)

    # 7. 保存
    with open(dist_path, "w", encoding="utf-8") as f:
        f.write(dist)

    return True


def main():
    for path in [DIST, DIST_MASTER]:
        fname = os.path.basename(path)
        print(f"\n--- {fname} ---")
        if enhance_dist_file(path):
            print(f"  ✓ {fname} 已增强")
        else:
            print(f"  ⚠ {fname} 增强失败")

    # 8. 记录日志
    import datetime
    with open(LOG_FILE, "w") as f:
        f.write(f"enhanced at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    sys.exit(0)


if __name__ == "__main__":
    main()
