#!/usr/bin/env python3
"""从 lhb_history.json 计算每只个股的连续出现在纯共振列表的天数，并查询行业分类"""

import json, os, sys
from datetime import datetime, timedelta

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
RESULT_FILE = os.path.join(DATA_DIR, "lhb_result.json")
HISTORY_FILE = os.path.join(DATA_DIR, "lhb_history.json")
SECTOR_CACHE_FILE = os.path.join(DATA_DIR, "stock_sector_cache.json")
OUTPUT_FILE = RESULT_FILE  # 直接覆盖

def load_json(path):
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def query_sector(code):
    """查询个股行业分类，优先用本地缓存"""
    cache = load_json(SECTOR_CACHE_FILE) or {}
    if code in cache and cache[code]:
        return cache[code]
    if code in cache:
        pass  # 之前查过但为空，再试一次
    try:
        import requests, time
        prefix = 'SZ' if code.startswith(('0','3')) else 'SH'
        headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://emweb.securities.eastmoney.com/'}
        r = requests.get(
            'https://emweb.securities.eastmoney.com/PC_HSF10/CompanySurvey/CompanySurveyAjax',
            params={'code': prefix + code},
            headers=headers,
            timeout=15
        )
        d = r.json()
        jbzl = d.get('jbzl', {})
        sector = jbzl.get('sshy', '').strip()
        if sector and sector != '-':
            cache[code] = sector
            save_json(SECTOR_CACHE_FILE, cache)
            return sector
    except Exception as e:
        print(f"    [WARN] 查询 {code} 行业失败: {e}")
    cache[code] = ""
    save_json(SECTOR_CACHE_FILE, cache)
    return ""

def main():
    result = load_json(RESULT_FILE)
    history = load_json(HISTORY_FILE)

    if not result or not result.get("stocks"):
        print("[LHB连续] lhb_result.json 无数据，跳过")
        return

    stocks = result["stocks"]
    if not history:
        print("[LHB连续] lhb_history.json 不存在，跳过")
        return

    # 获取 result 的日期
    result_date = result.get("date", "")
    if len(result_date) == 8:
        dt = datetime.strptime(result_date, "%Y%m%d")
    else:
        print(f"[LHB连续] 无法解析日期: {result_date}")
        return

    # 收集历史各日期的纯共振 stocks（按code为key）
    codes_by_date = {}
    for date_key, day_data in sorted(history.items()):
        if not day_data.get("trading"):
            continue
        pure_list = day_data.get("pure", [])
        codes = set()
        for item in pure_list:
            code = str(item.get("code", "")).strip()
            if code:
                codes.add(code)
        codes_by_date[date_key] = codes

    # 计算连续：向前倒推 trading days
    # 从当前日期前一天开始，倒序检查
    consecutive_lookup = {}
    for date_key in sorted(history.keys(), reverse=True):
        try:
            day_dt = datetime.strptime(date_key, "%Y-%m-%d")
        except:
            continue
        if day_dt >= dt:
            continue  # 跳过当前日及之后
        if day_dt < dt - timedelta(days=30):
            break  # 只看30天内

        if date_key not in codes_by_date:
            continue

        day_codes = codes_by_date[date_key]
        for code in day_codes:
            if code not in consecutive_lookup:
                consecutive_lookup[code] = {"last_date": date_key, "count": 1}
            else:
                prev = consecutive_lookup[code]
                try:
                    last_dt = datetime.strptime(prev["last_date"], "%Y-%m-%d")
                    # 倒序：last_date 是新日期，date_key 是旧日期
                    # 两个日期相差 ≤ 4 天（考虑周末）才算连续
                    gap = (last_dt - day_dt).days
                    if 1 <= gap <= 4:
                        prev["count"] += 1
                        prev["last_date"] = date_key
                except:
                    pass

    # 写入 stocks
    updated = 0
    sector_stats = {}
    for s in stocks:
        code = str(s.get("code", "")).strip()
        if code in consecutive_lookup:
            s["consecutive_days"] = consecutive_lookup[code]["count"] + 1  # +1 包括当天
        else:
            s["consecutive_days"] = 1
        # 只有纯共振才可能>1，非纯共振最多记1
        if s.get("category") != "纯共振":
            s["consecutive_days"] = 1
        # 查询行业分类（仅纯共振）
        if s.get("category") == "纯共振":
            sector = query_sector(code)
            if sector:
                s["sector"] = sector
                sector_stats[sector] = sector_stats.get(sector, 0) + 1
        updated += 1

    # 板块统计写入根节点
    if sector_stats:
        result["pure_sectors"] = sector_stats
        top = sorted(sector_stats.items(), key=lambda x: -x[1])
        result["pure_sector_top"] = top[0][0]
        result["pure_sector_count"] = len(sector_stats)
        print(f"  [LHB行业] 纯共振板块: {sector_stats}")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"[LHB连续] 已写入 {updated} 只个股的连续天数")

if __name__ == "__main__":
    main()
