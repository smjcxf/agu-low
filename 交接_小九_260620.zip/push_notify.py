#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
九宝量化 - 信号推送通知 (ntfy)
收盘后扫描 scan_result.json，推送三线共振/四喜临门信号股到手机

配置方式(三选一):
  1. 环境变量: NTFY_URL = "https://ntfy.sh/你的topic"
  2. config.json: {"ntfy_url": "https://ntfy.sh/你的topic"}
  3. 自建ntfy: 部署 ntfy 服务后填入你的服务器地址

用法: python push_notify.py [--dry-run]
"""

import json
import os
import sys
import requests
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
SCAN_RESULT = os.path.join(DATA_DIR, "scan_result.json")

# ============== 配置 ==============
NTFY_URL = os.environ.get("NTFY_URL", "")

if not NTFY_URL:
    config_file = os.path.join(DATA_DIR, "push_config.json")
    if os.path.exists(config_file):
        try:
            with open(config_file, "r") as f:
                cfg = json.load(f)
            NTFY_URL = cfg.get("ntfy_url", "")
        except:
            pass


def load_scan():
    if not os.path.exists(SCAN_RESULT):
        return None
    with open(SCAN_RESULT, "r", encoding="utf-8") as f:
        return json.load(f)


def build_message(scan):
    """构造推送消息"""
    results = scan.get("all_results", [])
    sizhu = [s for s in results if s.get("三足鼎立")]
    sanxian = [s for s in results if s.get("三线共振") and not s.get("三足鼎立")]
    shuangxian = [s for s in results if s.get("signal_count", 0) == 2]

    total = scan.get("total_scanned", 0)
    update_time = scan.get("scan_time", datetime.now().strftime("%H:%M"))

    lines = [f"九宝量化 {update_time} 扫描 {total} 只"]

    if sizhu:
        sizhu_list = ", ".join(f"{s['name']}({s.get('signal_score', s.get('signal_count',0)*3)}分)" for s in sizhu[:5])
        lines.append(f"四喜临门 {len(sizhu)}: {sizhu_list}")

    if sanxian:
        sanxian_list = ", ".join(f"{s['name']}({s.get('signal_score', s.get('signal_count',0)*3)}分)" for s in sanxian[:5])
        lines.append(f"三线共振 {len(sanxian)}: {sanxian_list}")

    if shuangxian:
        lines.append(f"双线共振 {len(shuangxian)} 只待观察")

    if not sizhu and not sanxian:
        lines.append("今日无三线共振/四喜临门信号")

    return "\n".join(lines)


def send_ntfy(message, title="九宝量化信号"):
    """发送ntfy推送"""
    if not NTFY_URL:
        print("[推送] NTFY_URL 未配置，跳过推送")
        return False

    try:
        r = requests.post(
            NTFY_URL,
            data=message.encode("utf-8"),
            headers={
                "Title": title,
                "Priority": "high",
                "Tags": "chart_with_upwards_trend",
            },
            timeout=10,
        )
        if r.status_code in (200, 201):
            print(f"[推送] 已发送到 {NTFY_URL}")
            return True
        else:
            print(f"[推送] 失败 HTTP {r.status_code}: {r.text}")
            return False
    except Exception as e:
        print(f"[推送] 异常: {e}")
        return False


if __name__ == "__main__":
    dry_run = "--dry-run" in sys.argv

    scan = load_scan()
    if not scan:
        print("[推送] 无扫描结果，跳过")
        sys.exit(0)

    msg = build_message(scan)

    if dry_run:
        print("=" * 40)
        print("[DRY RUN] 预览推送内容:")
        print(msg)
        print("=" * 40)
    else:
        send_ntfy(msg)
